int n1=5;
int n2=10;
int n3=20;

void add(void){
	n3=n1+n2;
}
