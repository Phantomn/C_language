#include <stdio.h>

int main(){
	printf("%x %x %x\n",main,printf,scanf);

	return 0;
}
