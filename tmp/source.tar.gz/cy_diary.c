#include <stdio.h>

int main(){
	char str[1000];
	
	printf("문자열을 입력하시오 : ");
	scanf("%s",str);

	int i;

	while(1){
		if(str[i]=='p'){


	printf("%s\n",str);

	return 0;
}
