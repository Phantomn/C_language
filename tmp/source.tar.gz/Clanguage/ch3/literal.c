#include <stdio.h>

int main(){
	printf("%d + %d = %d\n",10,20,10+20);

	return 0;
}
