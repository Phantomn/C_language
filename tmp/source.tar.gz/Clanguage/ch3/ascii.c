#include <stdio.h>

int main(){
	char ch='a';

	printf("a upper : %c\n",ch-32);

	return 0;
}
