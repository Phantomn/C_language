#include <stdio.h>

void main(){
	int i;
	int ymca_2010;
	int freeLec;
	int a, A;
	int howTo=20;
	int one_two;
	
	printf("howTo = %d",howTo);
}
