#include <stdio.h>

int main(){
	const int NUM=100;
	const double PI=3.14;

	return 0;
}
