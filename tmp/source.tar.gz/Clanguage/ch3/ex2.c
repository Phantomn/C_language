#include <stdio.h>

void main(){
	int jean=0;
	jean=1;
	jean++;
	printf("구매할 청바지 수량 = %d\n",jean);
	printf("구매완료\n");
}
