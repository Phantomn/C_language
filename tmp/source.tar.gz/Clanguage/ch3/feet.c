#include <stdio.h>

int main(){
	double feet = 30.48;

	double my_height=15000;

	double result=feet*my_height;

	int meter = result/100;


	printf("나는 현재 %d m위에 떠있습니다.\n",meter);

	return 0;
}
