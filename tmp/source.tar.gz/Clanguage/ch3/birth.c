#include <stdio.h>

void main(){
	int birth=19930819;

	printf("my birth : %d\n",birth);
}
