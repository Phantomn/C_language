#include <stdio.h>

int main(){
	double pound = 0.453592;

	double meal=pound*150;

	printf("%lf\n",meal);

	return 0;
}
