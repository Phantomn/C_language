#include <stdio.h>

int main(){
	printf("%d + %d = %d\n",3,5,3+5);
	printf("%i + %i = %i\n",3,5,3+5);
	printf("%d - %d = %d\n",3,5,3-5);
	printf("%i - %i = %i\n",3,5,3-5);

	return 0;
}
