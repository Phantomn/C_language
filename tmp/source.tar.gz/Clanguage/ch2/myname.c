#include <stdio.h>

int main(){
	printf("이름 : 홍승표, 학번 : 201202051\n");

	return 0;
}
