#include <stdio.h>

int main(){
	printf("decimal : %d is hex : %x, oct : %o.\n",50,50,50);
	printf("decimal : %d is hex : %x, oct : %o.\n",-50,-50,-50);

	return 0;

}
