#include <stdio.h>

int main(){
	printf("decimal integer : %d\n",0.5);
	printf("decimal float : %f\n",0.5);
	printf("decimal lfloat : %lf\n",0.5);

	printf("floating point 6 over : %f\n",0.5655678);
	printf("floating point 6 over : %lf\n",0.5667784);

	return 0;
}
	
