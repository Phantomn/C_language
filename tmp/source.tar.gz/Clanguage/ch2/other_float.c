#include <stdio.h>

void main(){
	printf("%f\n",0.000123);
	printf("%f\n",0.0001236);

	printf("%e\n", 0.000123);
	printf("%e\n", 0.0001236);
	


	printf("%g\n", 0.000123);
	printf("%G\n", 0.000123456);


	printf("올해 우리나라 경제 성장률은 5%%입니다.\n");

	return 0;
}
