#include <stdio.h>

int main(){
	printf("\t Hello ! \n Hello World! \n");
	printf("큰따옴표 : \" \" \n");
	printf("작은 따옴표 : \' \' \n");
	printf("역슬래시 : \\ \n");

	return 0;
}
