#include <stdio.h>

int main(){
	int ascii;

	printf("Input the ASCII : ");
	scanf("%d",&ascii);

	printf("입력한 코드에 해당하는 문자는 %c 입니다\n",ascii);
	
	return 0;
}
