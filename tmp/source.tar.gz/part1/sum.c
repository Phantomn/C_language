#include <stdio.h>

int main(){
	int a,b;


	while(1){
		printf("first number : ");
		scanf("%d",&a);
		printf("second number : ");
		scanf("%d",&b);

		printf("%d + %d = %d\n",a,b,a+b);
	}
	return 0;
}
