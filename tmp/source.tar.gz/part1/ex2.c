#include <stdio.h>


int main(){
	int c=200;

	printf("c=%d \n",c);

	return 0;
}
