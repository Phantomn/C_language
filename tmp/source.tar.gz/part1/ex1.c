#include <stdio.h>


int main(){
	float num;

	printf("실수를 입력하세요 : ");
	scanf("%f", &num);

	printf("당신이 입력한 수는 %.2f  입니다.\n", num);

	return 0;
}
