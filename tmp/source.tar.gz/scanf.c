#include <stdio.h>

void main(){
	int i;
	scanf("%d",&i);
	printf("%d\n",i);
}
